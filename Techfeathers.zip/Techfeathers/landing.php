<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Techfeathers - Modern Poultry Management System</title>
    <link rel="stylesheet" href="Techfeathers/assets/css/style.css">
    <style>
        /* Landing page specific styles */
        .landing-container {
            background: linear-gradient(135deg, #f8fbf9 0%, #e9ebee 100%);
            min-height: 100vh;
        }

        .hero {
            padding: 80px 0;
            text-align: center;
            background: linear-gradient(135deg, rgba(46, 204, 113, 0.05) 0%, rgba(39, 174, 96, 0.02) 100%);
        }

        .hero h1 {
            font-size: 3.5rem;
            font-weight: 800;
            color: #1c1c1c;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero .tagline {
            font-size: 1.4rem;
            color: #616161;
            margin-bottom: 40px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            padding: 16px 32px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            display: inline-block;
            border: none;
            cursor: pointer;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(46, 204, 113, 0.3);
            text-decoration: none;
            color: white;
        }

        .btn-secondary {
            background: transparent;
            color: var(--primary);
            padding: 16px 32px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            display: inline-block;
            border: 2px solid var(--primary);
        }

        .btn-secondary:hover {
            background: var(--primary);
            color: white;
            text-decoration: none;
            transform: translateY(-2px);
        }

        .features {
            padding: 80px 0;
            background: white;
        }

        .features h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #1c1c1c;
        }

        .features .subtitle {
            text-align: center;
            font-size: 1.2rem;
            color: #616161;
            margin-bottom: 60px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .feature-card {
            padding: 30px;
            border-radius: 16px;
            background: rgba(46, 204, 113, 0.03);
            border: 1px solid rgba(46, 204, 113, 0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(46, 204, 113, 0.15);
        }

        .feature-icon {
            font-size: 3rem;
            margin-bottom: 20px;
            display: block;
        }

        .feature-card h3 {
            font-size: 1.4rem;
            margin-bottom: 15px;
            color: #1c1c1c;
        }

        .feature-card p {
            color: #616161;
            line-height: 1.6;
            font-size: 1rem;
        }

        .benefits {
            padding: 80px 0;
            background: linear-gradient(135deg, #f8fbf9 0%, #e9ebee 100%);
        }

        .benefits h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #1c1c1c;
        }

        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-top: 60px;
        }

        .benefit-item {
            text-align: center;
        }

        .benefit-number {
            font-size: 3rem;
            font-weight: 800;
            color: var(--primary);
            margin-bottom: 10px;
        }

        .benefit-label {
            font-size: 1.2rem;
            color: #616161;
            font-weight: 600;
        }


        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .hero .tagline {
                font-size: 1.2rem;
            }
            
            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .features h2,
            .benefits h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="landing-container">
        <!-- Hero Section -->
        <section class="hero">
            <div class="container">
                <h1>Techfeathers</h1>
                <p class="tagline">Modern Poultry Management System for Smart Farmers</p>
                <div class="cta-buttons">
                    <a href="Techfeathers/" class="btn-primary">Access System</a>
                    <a href="#features" class="btn-secondary">Learn More</a>
                </div>
            </div>
        </section>

        <!-- Features Section -->
        <section class="features" id="features">
            <div class="container">
                <h2>Powerful Features for Poultry Management</h2>
                <p class="subtitle">Everything you need to efficiently manage your poultry operation in one comprehensive system</p>
                
                <div class="features-grid">
                    <div class="feature-card">
                        <span class="feature-icon">🐔</span>
                        <h3>Flock Management</h3>
                        <p>Track chicken batches, monitor breed types, manage quantities, and keep detailed status records for optimal flock health.</p>
                    </div>
                    
                    <div class="feature-card">
                        <span class="feature-icon">🥚</span>
                        <h3>Egg Production Tracking</h3>
                        <p>Record daily egg collection, monitor production trends, and analyze yield patterns to maximize profitability.</p>
                    </div>
                    
                    <div class="feature-card">
                        <span class="feature-icon">🌾</span>
                        <h3>Feed Inventory</h3>
                        <p>Manage feed stock levels, track consumption rates, and receive alerts for timely reordering to never run out.</p>
                    </div>
                    
                    <div class="feature-card">
                        <span class="feature-icon">💰</span>
                        <h3>Financial Management</h3>
                        <p>Record sales, track expenses, monitor revenue streams, and maintain comprehensive financial records.</p>
                    </div>
                    
                    <div class="feature-card">
                        <span class="feature-icon">📊</span>
                        <h3>Analytics Dashboard</h3>
                        <p>View real-time KPIs, track performance trends, and make data-driven decisions with visual reports.</p>
                    </div>
                    
                    <div class="feature-card">
                        <span class="feature-icon">👥</span>
                        <h3>User Management</h3>
                        <p>Multi-user support with role-based access, secure authentication, and personalized dashboards.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Benefits Section -->
        <section class="benefits">
            <div class="container">
                <h2>Why Choose Techfeathers?</h2>
                
                <div class="benefits-grid">
                    <div class="benefit-item">
                        <div class="benefit-number">50%</div>
                        <div class="benefit-label">Time Saved on Manual Tracking</div>
                    </div>
                    
                    <div class="benefit-item">
                        <div class="benefit-number">30%</div>
                        <div class="benefit-label">Increase in Productivity</div>
                    </div>
                    
                    <div class="benefit-item">
                        <div class="benefit-number">24/7</div>
                        <div class="benefit-label">Access to Your Data</div>
                    </div>
                    
                    <div class="benefit-item">
                        <div class="benefit-number">100%</div>
                        <div class="benefit-label">Data Security</div>
                    </div>
                </div>
            </div>
        </section>

    </div>
</body>
</html>
